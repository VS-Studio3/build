<?php
/**
 * JBZoo is universal CCK based Joomla! CMS and YooTheme Zoo component
 * @category   JBZoo
 * @author     smet.denis <admin@joomla-book.ru>
 * @copyright  Copyright (c) 2009-2012, Joomla-book.ru
 * @license    http://joomla-book.ru/info/disclaimer
 * @link       http://joomla-book.ru/projects/jbzoo JBZoo project page
 */
defined('_JEXEC') or die('Restricted access');

class JBEventCategory extends JBEvent
{

    public static function init($event)
    {

    }

    public static function saved($event)
    {

    }

    public static function deleted($event)
    {

    }

    public static function stateChanged($event)
    {

    }
}