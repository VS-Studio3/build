<?php
defined('_JEXEC') or die('Restricted access');
?>

<tr class="table-row item_<?php echo $item->id;?>">
    <td><?php echo $this->renderPosition('cell1'); ?></td>
    <td><?php echo $this->renderPosition('cell2'); ?></td>
    <td><?php echo $this->renderPosition('cell3'); ?></td>
    <td><?php echo $this->renderPosition('cell5'); ?></td>
    <td><?php echo $this->renderPosition('cell6'); ?></td>
    <td><?php echo $this->renderPosition('cell7'); ?></td>
    <td><?php echo $this->renderPosition('cell8'); ?></td>
</tr>